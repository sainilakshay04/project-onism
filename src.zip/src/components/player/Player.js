//https://www.youtube.com/watch?v=M4TTeSVX3HI&t=0s
import PlayerDetails from './PlayerDetails'
import PlayerControls from './PlayerControls'
function Player(props) {
    return (
      <div className="player-comp">
        <audio src={props.song.src}></audio>
        <h4>Now Playing</h4>
        <PlayerDetails song={props.song}/>
        <PlayerControls />
    </div>
    );
  }
  
export default Player;