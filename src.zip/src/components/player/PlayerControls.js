function PlayerControls() {
    return (
        <div className="player-controls">
          <button className="nav-btn">Prev</button>
          <button className="play-btn">Play</button>
          <button className="nav-btn">Next</button>
        </div>
    );
  }
  
export default PlayerControls;